import fetchBreeds from './js/catapi.js'
fetchBreeds().then (res=> console.log (res))