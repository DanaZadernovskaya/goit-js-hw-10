
export function fetchBreeds() {return fetch('https://api.thecatapi.com/v1/breeds?api_key=live_ZVicieLEy4HcRqObQEb2BO2VkG9UifclM8wHG7MTX2MpeTn4QXVlTsBbmrNteMAs', {
   headers: {
      
   }
}) }
     
